-- 创建数据库
CREATE DATABASE IF NOT EXISTS member_management;

-- Use the database
USE member_management;

-- Create the students table
CREATE TABLE IF NOT EXISTS students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    age INT NOT NULL,
    major VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert some sample data
INSERT INTO students (student_id, name, password, gender, age, major, email) VALUES
('2024001', '张三', 'password123', '男', 20, '计算机科学与技术', 'zhangsan@example.com'),
('2024002', '李四', 'password123', '女', 21, '大数据科学', 'lisi@example.com'),
('2024003', '王五', 'password123', '男', 19, '软件工程', 'wangwu@example.com'); 